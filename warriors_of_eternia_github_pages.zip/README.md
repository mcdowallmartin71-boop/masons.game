# Warriors of Eternia

A browser-based 16-bit style arcade beat-'em-up.

## Play with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html` to the root of the repository.
3. In GitHub, go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder.
6. Save.
7. GitHub will provide a public Pages URL for the game.

## Controls

### iPhone / Touch
- Left virtual stick: Move
- ATK: Attack
- HEAVY: Heavy attack
- JUMP: Jump
- SP: Special attack
- Pause button: Pause
- Best played in landscape orientation

### Desktop
- WASD / Arrow Keys: Move
- J: Attack
- K: Heavy attack
- Space: Jump
- L: Special attack
- P: Pause
